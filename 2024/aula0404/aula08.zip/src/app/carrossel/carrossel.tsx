
const Carrossel = () =>{
    return(
        <>
            <div className="content">
                <div className="Carrossel"></div>
            </div>
        </>
    )
}
export default Carrossel;