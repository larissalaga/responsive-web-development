
const Footer = () =>{
    return(
        <>
            <footer>
                <div className="content">
                    <h1>Footer</h1>
                </div>
            </footer>
        </>
    )
}
export default Footer;