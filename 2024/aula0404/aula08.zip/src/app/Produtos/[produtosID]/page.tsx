
const Info = ({ params }) =>{
    return(
        <>
            <div className="content">
                <h1>{params.produtosID}</h1>
            </div>
        </>
    )
}

export default Info;