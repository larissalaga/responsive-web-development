
const notfound = () =>{
    return(
        <>
            <div className="content">
                <h1>Página não encontrada</h1>
                <h2>Erro 404</h2>
            </div>
        </>
    )
}
export default  notfound; 