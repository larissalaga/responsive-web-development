
const Sobre = () =>{
    return(
        <>
         <div className="content">
            <h1>Sobre</h1>
        </div>
        </>
    )
}

export default Sobre;